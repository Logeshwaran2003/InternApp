package MRC.InternApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternAppApplication.class, args);
	}

}
