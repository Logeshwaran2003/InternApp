import React,{ useState } from "react";
import Task from "./Task";

import './Task1.css';

 

 

function Feedbackform(){

    const[showNextPage,setshowNextPage]=useState("");

 

    const handleButtonClick = () =>{

        setshowNextPage(true);

    }

 

   

    if(showNextPage){

       return <Task/>;

    }

    return(

        <div id="task">

          <nav>

           <img src="./App_icon.png"></img></nav>

          <h1>Task</h1>

          <div id="foot">

            

            <button onClick={handleButtonClick}>Create Task</button>
            
          </div>
          <div id="foot1">
          <button onClick={handleButtonClick}>Get Task</button>
          </div>
          <div id="foot2">
          <button onClick={handleButtonClick}>Update Task</button>
          </div>
          <div id="foot3">
          <button onClick={handleButtonClick}>Delete Task</button>
          </div>
        

        </div>

    );

 

}

export default Feedbackform;