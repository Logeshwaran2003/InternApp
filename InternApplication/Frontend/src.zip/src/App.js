
import './App.css';
import Task1 from "./Task1"
function App() {
  return (
    <Task1/>
  );
}

export default App;
