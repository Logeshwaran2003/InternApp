import React, { useState } from 'react';
import './Task.css'; // Import the CSS file
import axios from 'axios'; // Import Axios

 

const TaskPage = () => {
  const [task, setTask] = useState({
    name: '',
    description: '',
    dueDate: '',
    completed: ''
  });

 

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTask({
      ...task,
      [name]: value,
    });
  };

 

  const handleSubmit = (e) => {
    e.preventDefault();

 

    // Send a POST request to your server
    axios.post('http://localhost:8082/api/v1/task/createTask', task)
      .then(response => {
        console.log('Task submitted successfully:', response.data);
        // Reset the form or perform other actions as needed
        setTask({
          name: '',
          description: ''
        });
      })
      .catch(error => {
        console.error('Error submitting task:', error);
      });
  };
   
 

  return (
    <div id="demo">
      <nav>
<img src="./App_icon.png"></img></nav>
<h1>Create Task</h1>
<center>
<div id="container">
{/* <form className="task-form" onSubmit={handleSubmit}>
<div className="form-group">
<label>Name:</label>
<input
            type="text"
            name="name"
            value={task.name}
            onChange={handleInputChange}
            required
          />
<label>Description:</label>
<textarea
            name="description"
            value={task.description}
            onChange={handleInputChange}
            required
></textarea>
<label>DueDate:</label>
<input
            type="text"
            name="dueDate"
            value={task.dueDate}
            onChange={handleInputChange}
            required
          />
</div>



<button type="submit">Upload Task</button>
</form>
</div>
</div>
  );
}; */}

<form className="Box">
<label>Name: </label>&nbst;&nbst;
<input
            type="text"
            name="name"
            value={task.name}
            onChange={handleInputChange}
            required
          />
          <br/><br/>
<label>Description:</label>&nbst;
<input
            name="description"
            value={task.description}
            onChange={handleInputChange}
            required
            />

<br/><br/>
<label>DueDate:</label>&nbst;&nbst;
<input
            type="text"
            name="dueDate"
            value={task.dueDate}
            onChange={handleInputChange}
            required
          />
          <br/><br/><br/>



 


 


 


<button type="submit">Upload</button>

 
</form>

</div>
</center>
</div>



 


 

    );

 

}

 

 

export default TaskPage;
