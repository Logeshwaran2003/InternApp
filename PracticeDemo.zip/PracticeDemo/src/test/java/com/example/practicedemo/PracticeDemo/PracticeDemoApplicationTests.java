package com.example.practicedemo.PracticeDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
